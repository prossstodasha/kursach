﻿namespace Chess
{
    partial class Form1
    {
        /// <summary>
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// </summary>
        /// <param name="disposing"
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.ChessBoard = new System.Windows.Forms.Panel();
            this.MoveLabel = new System.Windows.Forms.Label();
            this.ResetButton = new System.Windows.Forms.Button();
            this.UseAiCheckBox = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // шахматная доска
            // 
            this.ChessBoard.Location = new System.Drawing.Point(13, 70);
            this.ChessBoard.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ChessBoard.Name = "ChessBoard";
            this.ChessBoard.Size = new System.Drawing.Size(600, 615);
            this.ChessBoard.TabIndex = 0;
          


            this.MoveLabel.AutoSize = true;
            this.MoveLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.MoveLabel.Location = new System.Drawing.Point(493, 9);
            this.MoveLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.MoveLabel.Name = "MoveLabel";
            this.MoveLabel.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.MoveLabel.Size = new System.Drawing.Size(98, 46);
            this.MoveLabel.TabIndex = 1;
            this.MoveLabel.Text = "Text";
            // 
            // стартовая кнопка
            // 
            this.ResetButton.BackColor = System.Drawing.Color.YellowGreen;
            this.ResetButton.Location = new System.Drawing.Point(268, 20);
            this.ResetButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ResetButton.Name = "ResetButton";
            this.ResetButton.Size = new System.Drawing.Size(112, 35);
            this.ResetButton.TabIndex = 2;
            this.ResetButton.Text = "Начать";
            this.ResetButton.UseVisualStyleBackColor = false;
            this.ResetButton.Click += new System.EventHandler(this.ResetButton_Click);
            // 
            // бот
            // 
            this.UseAiCheckBox.AutoSize = true;
            this.UseAiCheckBox.Location = new System.Drawing.Point(13, 34);
            this.UseAiCheckBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.UseAiCheckBox.Name = "UseAiCheckBox";
            this.UseAiCheckBox.Size = new System.Drawing.Size(179, 24);
            this.UseAiCheckBox.TabIndex = 4;
            this.UseAiCheckBox.Text = "Использоовать ИИ";
            this.UseAiCheckBox.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Chess.Properties.Resources.wood_1700562_1920;
            this.ClientSize = new System.Drawing.Size(629, 748);
            this.Controls.Add(this.ResetButton);
            this.Controls.Add(this.UseAiCheckBox);
            this.Controls.Add(this.MoveLabel);
            this.Controls.Add(this.ChessBoard);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form1";
            this.Text = "шахматы";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel ChessBoard;
        private System.Windows.Forms.Label MoveLabel;
        private System.Windows.Forms.Button ResetButton;
        private System.Windows.Forms.CheckBox UseAiCheckBox;
    }
}

