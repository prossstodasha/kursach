﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chess
{

    public enum ChessPieceColor { None, White, Black };
    public abstract class CPClass
    {
        public int x;
        public int y;

        public ChessPieceColor pieceColor;

        public string CPName = "NULL";

        public bool moved;

        public CPClass(int _x, int _y, ChessPieceColor _pieceColor)
        {
            x = _x;
            y = _y;
            pieceColor = _pieceColor;
            moved = false;
        }

        public abstract void GetAvailableMoves(ChessBoardNode[,] board, out List<AvailableMove> moves);

        protected bool AddMove(ChessBoardNode[,] board, int newX, int newY, List<AvailableMove> moveList, MoveType moveType = MoveType.MoveAndAttack)
        {
            
            if (newX < 8 && newX >= 0 && newY < 8 && newY >= 0)
            {
                AvailableMove newMove = new AvailableMove(board[newX, newY], moveType);
                if (board[newX, newY].chessPiece == null)
                {
                    if (moveType == MoveType.OnlyAttack) return false;
                    else
                    {
                        moveList.Add(newMove);
                        return true;
                    }
                }
                else
                {
                    if (board[newX, newY].chessPiece.pieceColor == pieceColor)
                    {
                        return false;
                    }
                    else if(moveType != MoveType.OnlyMove)
                    {
                        moveList.Add(newMove);
                        return false;
                    }
                    else
                    {
                        return false;
                    }
                }
            }
            else
            {
                return false;
            }
        }
    }

    public class CPPawn : CPClass
    {

        public bool movedDouble = false;
        public CPPawn(int _x, int _y, ChessPieceColor _pieceColor) : base(_x, _y, _pieceColor)
        {
            CPName = "Пешка";
        }

        public override void GetAvailableMoves(ChessBoardNode[,] board, out List<AvailableMove> moves)
        {
            moves = new List<AvailableMove>();


            

            if(pieceColor == ChessPieceColor.White)
            {
                //белые ходят
                AddMove(board, x + 1, y + 1, moves, MoveType.OnlyAttack);
                AddMove(board, x - 1, y + 1, moves, MoveType.OnlyAttack);

                if (AddMove(board, x, y + 1, moves, MoveType.OnlyMove))
                {
                    if (y == 1)
                    {
                        AddMove(board, x, y + 2, moves, MoveType.OnlyMove);
                    }
                }

            }
            else
            {
                //черные ходят
                AddMove(board, x + 1, y - 1, moves, MoveType.OnlyAttack);
                AddMove(board, x - 1, y - 1, moves, MoveType.OnlyAttack);

                if (AddMove(board, x, y - 1, moves, MoveType.OnlyMove))
                {
                    if (y == 6)
                    {
                        AddMove(board, x, y - 2, moves, MoveType.OnlyMove);
                    }
                }
            }
        }
    }

    public class CPRook : CPClass
    {
        public CPRook(int _x, int _y, ChessPieceColor _pieceColor) : base(_x, _y, _pieceColor)
        {
            CPName = "Ладья";
        }

        public override void GetAvailableMoves(ChessBoardNode[,] board, out List<AvailableMove> moves)
        {
            moves = new List<AvailableMove>();

            for (int i = 1; i < 8; i++) 
            { 
                if(!AddMove(board, x + i, y, moves))
                {
                    break;
                }
            }
            for (int i = 1; i < 8; i++)
            {
                if (!AddMove(board, x - i, y, moves))
                {
                    break;
                }
            }
            for (int i = 1; i < 8; i++)
            {
                if (!AddMove(board, x, y + i, moves))
                {
                    break;
                }
            }
            for (int i = 1; i < 8; i++)
            {
                if (!AddMove(board, x, y - i, moves))
                {
                    break;
                }
            }
        }
    }

    public class CPBishop : CPClass
    {
        public CPBishop(int _x, int _y, ChessPieceColor _pieceColor) : base(_x, _y, _pieceColor)
        {
            CPName = "Слон";
        }

        public override void GetAvailableMoves(ChessBoardNode[,] board, out List<AvailableMove> moves)
        {
            moves = new List<AvailableMove>();
            for (int i = 1; i < 8; i++)
            {
                if (!AddMove(board, x - i, y - i, moves))
                {
                    break;
                }
            }
            for (int i = 1; i < 8; i++)
            {
                if (!AddMove(board, x + i, y + i, moves))
                {
                    break;
                }
            }
            for (int i = 1; i < 8; i++)
            {
                if (!AddMove(board, x + i, y - i, moves))
                {
                    break;
                }
            }
            for (int i = 1; i < 8; i++)
            {
                if (!AddMove(board, x - i, y + i, moves))
                {
                    break;
                }
            }
        }
    }

    public class CPKnight : CPClass
    {
        public CPKnight(int _x, int _y, ChessPieceColor _pieceColor) : base(_x, _y, _pieceColor)
        {
            CPName = "Конь";
        }

        public override void GetAvailableMoves(ChessBoardNode[,] board, out List<AvailableMove> moves)
        {
            moves = new List<AvailableMove>();
            AddMove(board, x + 2, y + 1, moves);
            AddMove(board, x + 2, y - 1, moves);

            AddMove(board, x - 2, y + 1, moves);
            AddMove(board, x - 2, y + 1, moves);

            AddMove(board, x - 1, y - 2, moves);
            AddMove(board, x + 1, y - 2, moves);

            AddMove(board, x - 1, y + 2, moves);
            AddMove(board, x + 1, y + 2, moves);
        }
    }

    public class CPQueen : CPClass
    {
        public CPQueen(int _x, int _y, ChessPieceColor _pieceColor) : base(_x, _y, _pieceColor)
        {
            CPName = "Королева";
        }

        public override void GetAvailableMoves(ChessBoardNode[,] board, out List<AvailableMove> moves)
        {
            moves = new List<AvailableMove>();
            for (int i = 1; i < 8; i++)
            {
                if (!AddMove(board, x - i, y - i, moves))
                {
                    break;
                }
            }
            for (int i = 1; i < 8; i++)
            {
                if (!AddMove(board, x + i, y + i, moves))
                {
                    break;
                }
            }
            for (int i = 1; i < 8; i++)
            {
                if (!AddMove(board, x + i, y - i, moves))
                {
                    break;
                }
            }
            for (int i = 1; i < 8; i++)
            {
                if (!AddMove(board, x - i, y + i, moves))
                {
                    break;
                }
            }
            for (int i = 1; i < 8; i++)
            {
                if (!AddMove(board, x + i, y, moves))
                {
                    break;
                }
            }
            for (int i = 1; i < 8; i++)
            {
                if (!AddMove(board, x - i, y, moves))
                {
                    break;
                }
            }
            for (int i = 1; i < 8; i++)
            {
                if (!AddMove(board, x, y + i, moves))
                {
                    break;
                }
            }
            for (int i = 1; i < 8; i++)
            {
                if (!AddMove(board, x, y - i, moves))
                {
                    break;
                }
            }
        }
    }

    public class CPKing : CPClass
    {
        public CPKing(int _x, int _y, ChessPieceColor _pieceColor) : base(_x, _y, _pieceColor)
        {
            CPName = "Король";
        }

        public override void GetAvailableMoves(ChessBoardNode[,] board, out List<AvailableMove> moves)
        {
            moves = new List<AvailableMove>();
            for(int xx = -1; xx < 2; xx++)
            {
                for(int yy = -1; yy < 2; yy++)
                {
                     AddMove(board, x + xx, y + yy, moves);
                }
            }

            if(pieceColor == ChessPieceColor.White)
            {
                if(x == 4 && y == 0 && moved == false)
                {
                    if(board[7, 0].chessPiece != null)
                    {
                        if (board[7, 0].chessPiece.moved == false && board[6, 0].chessPiece == null && board[5, 0].chessPiece == null)
                        {
                            moves.Add(new AvailableMove(board[6, 0], MoveType.Castling));
                        }
                    }

                    if (board[0, 0].chessPiece != null)
                    {
                        if (board[0, 0].chessPiece.moved == false && board[1, 0].chessPiece == null && board[2, 0].chessPiece == null && board[3, 0].chessPiece == null)
                        {
                            moves.Add(new AvailableMove(board[2, 0], MoveType.Castling));
                        }
                    }
                }
            }
            else
            {

            }
        }
    }
}
